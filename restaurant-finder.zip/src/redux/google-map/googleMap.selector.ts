import { RootState } from "../root.reducer";

export const gmapSelector = (state: RootState) => state.googleMap;
